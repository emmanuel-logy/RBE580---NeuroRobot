#include <vtkBYUReader.h>
#include <vtkOBJReader.h>
#include <vtkPLYReader.h>
#include <vtkPolyDataReader.h>
#include <vtkSTLReader.h>
#include <vtkXMLPolyDataReader.h>

#include <vtkActor.h>
#include <vtkCamera.h>
#include <vtkCellArray.h>
#include <vtkCenterOfMass.h>
#include <vtkCollisionDetectionFilter.h>
#include <vtkCutter.h>
#include <vtkCylinderSource.h>
#include <vtkDataSetMapper.h>
#include <vtkDoubleArray.h>
#include <vtkGeometryFilter.h>
#include <vtkIntersectionPolyDataFilter.h>
#include <vtkLine.h>
#include <vtkLineSource.h>
#include <vtkMatrix4x4.h>
#include <vtkMultiBlockDataSet.h>
#include <vtkMultiThreshold.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPointData.h>
#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSelectEnclosedPoints.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>
#include <vtkStripper.h>
#include <vtkTextActor.h>
#include <vtkTextProperty.h>
#include <vtkTimerLog.h>
#include <vtkTransform.h>
#include <vtkTransformFilter.h>
#include <vtkTransformPolyDataFilter.h>
#include <vtkTubeFilter.h>
#include <vtkUnstructuredGrid.h>
#include <vtksys/SystemTools.hxx>

#include <algorithm> // For transform()
#include <cctype>    // For to_lower
#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>
#include <sstream>
#include <string>
#include <thread>

namespace {
vtkSmartPointer<vtkPolyData> ReadPolyData(const char* fileName);
}

int main(int argc, char* argv[])
{
  std::ofstream myfile;
  myfile.open ("entryPoints.txt");
  auto geometryFilter = vtkSmartPointer<vtkGeometryFilter>::New();
  vtkNew<vtkNamedColors> colors;  
  //Model Files
  auto skullPoly = ReadPolyData("Skull.vtk");
  auto tumorPoly = ReadPolyData("Tumor.vtk");
  auto matPoly = ReadPolyData("White Matter.vtk");

  // Visualize polydata
  vtkNew<vtkPolyDataMapper> skullMapper;
  skullMapper->SetInputData(skullPoly);
  vtkNew<vtkPolyDataMapper> tumorMapper;
  tumorMapper->SetInputData(tumorPoly);
  vtkNew<vtkPolyDataMapper> matMapper;
  matMapper->SetInputData(matPoly);

  //Find center of tumor for needl
  vtkNew<vtkCenterOfMass> centerOfMassFilter;
  centerOfMassFilter->SetInputData(tumorPoly);
  centerOfMassFilter->SetUseScalarsAsWeights(false);
  centerOfMassFilter->Update();
  
  double center[3];
  centerOfMassFilter->GetCenter(center);
  vtkNew<vtkLineSource> lineSource;
  lineSource->SetPoint1(center[0],center[1],center[2]);
  double xBase = 0.0;
  double yBase = -60.0;
  double zBase = 140.0;
  lineSource->SetPoint2(xBase, yBase, zBase);

  //Visual characteristics for .vtk models
  vtkNew<vtkProperty> backProp;
  backProp->SetDiffuseColor(colors->GetColor3d("Banana").GetData());
  backProp->SetSpecular(0.6);
  backProp->SetSpecularPower(30);

  //Actors for brain featurs
  vtkNew<vtkActor> skullActor;
  skullActor->SetMapper(skullMapper);
  skullActor->SetBackfaceProperty(backProp);
  skullActor->GetProperty()->SetSpecular(0.3);
  skullActor->GetProperty()->SetSpecularPower(30);
  skullActor->GetProperty()->SetOpacity(0.1); 

  vtkNew<vtkActor> tumorActor;
  tumorActor->SetMapper(tumorMapper);
  tumorActor->SetBackfaceProperty(backProp);
  tumorActor->GetProperty()->SetSpecular(0.3);
  tumorActor->GetProperty()->SetSpecularPower(30);
  tumorActor->GetProperty()->SetOpacity(1.0); 

  vtkNew<vtkActor> matActor;
  matActor->SetMapper(matMapper);
  matActor->SetBackfaceProperty(backProp);
  matActor->GetProperty()->SetSpecular(0.3);
  matActor->GetProperty()->SetSpecularPower(30);
  matActor->GetProperty()->SetOpacity(0.5); 

  // Create a mapper and actor for line
  vtkNew<vtkPolyDataMapper> lineMapper;
  lineMapper->SetInputConnection(lineSource->GetOutputPort());
  vtkNew<vtkActor> lineActor;
  lineActor->GetProperty()->SetColor(colors->GetColor3d("Red").GetData());
  lineActor->SetMapper(lineMapper);

  // Create a tube (cylinder) around the line
  vtkNew<vtkTubeFilter> tubeFilter;
  tubeFilter->SetInputConnection(lineSource->GetOutputPort());
  tubeFilter->SetRadius(2); // default is .5
  tubeFilter->SetNumberOfSides(10);  
  tubeFilter->CappingOn();
  tubeFilter->Update();

  geometryFilter->SetInputConnection(tubeFilter->GetOutputPort());
  geometryFilter->Update();

  vtkPolyData* tubePoly = geometryFilter->GetOutput();
  vtkNew<vtkPolyDataMapper> tubePolyMapper;
  tubePolyMapper->SetInputData(tubePoly);
  vtkNew<vtkActor> tubePolyActor;
  tubePolyActor->SetMapper(tubePolyMapper);
  tubePolyActor->SetBackfaceProperty(backProp);
  tubePolyActor->GetProperty()->SetSpecular(0.3);
  tubePolyActor->GetProperty()->SetSpecularPower(30);
  tubePolyActor->GetProperty()->SetOpacity(0.1); 
  // Create a mapper and actor for tube
  vtkNew<vtkPolyDataMapper> tubeMapper;
  tubeMapper->SetInputConnection(tubeFilter->GetOutputPort());
  vtkNew<vtkActor> tubeActor;
  tubeActor->GetProperty()->SetOpacity(0.9); // Make the tube have some transparency.
  tubeActor->SetMapper(tubeMapper);

  vtkNew<vtkMatrix4x4> matrix1;
  vtkNew<vtkTransform> transform0;

  vtkNew<vtkCollisionDetectionFilter> collide;
  collide->SetInputData(0, tubePoly);
  collide->SetTransform(0, transform0);
  collide->SetInputData(1, matPoly);
  collide->SetMatrix(1, matrix1);
  collide->SetBoxTolerance(0.0);
  collide->SetCellTolerance(0.0);
  collide->SetNumberOfCellsPerNode(2);
  collide->Update();
  collide->SetCollisionModeToAllContacts();

  vtkNew<vtkCollisionDetectionFilter> burrCollide;
  burrCollide->SetInputData(0, tubePoly);
  burrCollide->SetTransform(0, transform0);
  burrCollide->SetInputData(1, skullPoly);
  burrCollide->SetMatrix(1, matrix1);
  burrCollide->SetBoxTolerance(0.0);
  burrCollide->SetCellTolerance(0.0);
  burrCollide->SetNumberOfCellsPerNode(2);
  burrCollide->Update();
  burrCollide->SetCollisionModeToAllContacts();

  vtkNew<vtkCenterOfMass> burrCOM;
  burrCOM->SetInputData(burrCollide->GetContactsOutput());
  burrCOM->SetUseScalarsAsWeights(false);

  double burrCenter[3];
  //burrCOM->Update();

  vtkNew<vtkTextActor> txt;
  txt->GetTextProperty()->SetFontSize(15);

  vtkNew<vtkRenderer> renderer;
  renderer->UseHiddenLineRemovalOn();
  renderer->AddActor(txt);
  //renderer->AddActor(tubeActor);
  renderer->AddActor(lineActor);
  renderer->AddActor(skullActor);
  renderer->AddActor(tumorActor);
  renderer->AddActor(matActor);
  renderer->AddActor(tubePolyActor);
  renderer->SetBackground(colors->GetColor3d("Gray").GetData());
  renderer->UseHiddenLineRemovalOn();

  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->SetSize(640, 480);
  renderWindow->AddRenderer(renderer);

  vtkNew<vtkRenderWindowInteractor> interactor;
  interactor->SetRenderWindow(renderWindow);

  int thetaSteps = 45;
  int phiSteps = 360;
  double theta = 0;
  double phi = 0;
  double rad = 127.0;
  double dTheta = 1;
  double dPhi = -1;
  double radToDeg = 0.0174533;
  double xLine = rad*sin(theta*radToDeg)*cos(phi*radToDeg);
  double yLine = rad*sin(theta*radToDeg)*sin(phi*radToDeg);
  double zLine = rad*cos(theta*radToDeg);
  
  renderWindow->Render();

  renderWindow->SetWindowName("RBE580_project");
  renderWindow->Render();

  for (int i = 0; i < phiSteps*thetaSteps; ++i)
  {
    geometryFilter->Update();
    vtkPolyData* tubePoly = geometryFilter->GetOutput();
    collide->Update();
    burrCollide->Update();
    if(burrCollide->GetNumberOfContacts()>1)
    {
      burrCOM->Update();
      burrCOM->GetCenter(burrCenter);
    }
    phi += dPhi;
    if (i%phiSteps == 0)
    {
    dPhi = -dPhi; 
    theta += dTheta;
    }
    xLine = xBase + rad*sin(theta*radToDeg)*cos(phi*radToDeg);
    yLine = yBase + rad*sin(theta*radToDeg)*sin(phi*radToDeg);
    zLine = zBase + rad*cos(theta*radToDeg);
    lineSource->SetPoint2(xLine, yLine, zLine);
    renderer->ResetCameraClippingRange();
    std::ostringstream textStream;
    textStream <<": Skull collisions  " 
               << burrCollide->GetNumberOfContacts()
               <<": White matter collisions "
               << collide->GetNumberOfContacts()
               << ": Theta is "
               << theta
               <<": Phi is "
               << phi
               << ": X "
               << burrCenter[0]
               <<": Y "
               << burrCenter[1]
               <<": Z "
               <<burrCenter[2];
    txt->SetInput(textStream.str().c_str());
    renderWindow->Render();
    if (collide->GetNumberOfContacts() < 1)
    {
      if(myfile.is_open() == false)
      {
        myfile.open("entryPoints.txt", std::ios_base::app);;
      }
      myfile << burrCenter[0] << " " << burrCenter[1] << " " << burrCenter[2] << "\n";
      myfile.close();

      //std::cout << "A viable entry point is " << xLine << " " << yLine << " " << zLine << std::endl;
    }
    interactor->ProcessEvents();
    
    // The total animation time is 3 seconds
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
   
  }
  renderer->ResetCamera();
  renderWindow->Render();
  interactor->Start();
  // In Field Data there will be an array named "ContactCells".
  // This array indexes contacting cells (e.g.) index 50 of array 0
  //  points to a cell (triangle) which contacts/intersects a cell
  //  at index 50 of array 1.
  // You can directly obtain these, see GetContactCells(int i)
  //  in the documentation.
  // collide->GetOutput(0)->Print(std::cout);
  // collide->GetOutput(1)->Print(std::cout);
  return EXIT_SUCCESS;
}

namespace {
vtkSmartPointer<vtkPolyData> ReadPolyData(const char* fileName)
{
  vtkSmartPointer<vtkPolyData> polyData;
  std::string extension =
      vtksys::SystemTools::GetFilenameLastExtension(std::string(fileName));

  // Drop the case of the extension
  std::transform(extension.begin(), extension.end(), extension.begin(),
                 ::tolower);

  if (extension == ".ply")
  {
    vtkNew<vtkPLYReader> reader;
    reader->SetFileName(fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".vtp")
  {
    vtkNew<vtkXMLPolyDataReader> reader;
    reader->SetFileName(fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".obj")
  {
    vtkNew<vtkOBJReader> reader;
    reader->SetFileName(fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".stl")
  {
    vtkNew<vtkSTLReader> reader;
    reader->SetFileName(fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".vtk")
  {
    vtkNew<vtkPolyDataReader> reader;
    reader->SetFileName(fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".g")
  {
    vtkNew<vtkBYUReader> reader;
    reader->SetGeometryFileName(fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else
  {
    vtkNew<vtkSphereSource> source;
    source->Update();
    polyData = source->GetOutput();
  }

  return polyData;
}
} // namespace
